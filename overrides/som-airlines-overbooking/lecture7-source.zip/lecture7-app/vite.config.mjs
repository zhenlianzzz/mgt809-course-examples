import {defineConfig} from 'vite';
export default defineConfig({base:'./',esbuild:{jsx:'automatic'},build:{outDir:'../overrides/som-airlines-overbooking',emptyOutDir:true}});

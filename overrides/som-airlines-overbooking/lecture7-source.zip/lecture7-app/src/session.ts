export const CHECKIN_URL = 'https://script.google.com/macros/s/AKfycbxfYP-Ye9VfES4hc2hsoIZWI-99bVpepUlIVeIm04DsJK-rUDHfEXQu1e2q7WWzdYMezw/exec?lecture=7&date=2026-11-19';
